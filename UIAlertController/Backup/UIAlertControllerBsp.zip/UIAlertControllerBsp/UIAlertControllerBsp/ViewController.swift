//
//  ViewController.swift
//  UIAlertControllerBsp
//
//  Created by Christian Bleske on 22.12.14.
//  Copyright (c) 2014 Christian Bleske. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIActionSheetDelegate {

    @IBOutlet weak var uiLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnStdUIAlertControllerPressed(sender: AnyObject) {
        let uiAlertController = UIAlertController(title: "Standard Alert", message: "Beispiel für einen Standard-Dialog.", preferredStyle: .Alert)
        
        let cancelAction = UIAlertAction(title: "Abbrechen", style: .Cancel) { (action) in
            // Code welcher bei Betätigung des Abbrechen-Button ausgeführt wird...
            self.uiLabel.text = "Abbrechen-Button wurde betätigt"
        }
        uiAlertController.addAction(cancelAction)
        
        let OKAction = UIAlertAction(title: "Ok", style: .Default) { (action) in
            // Code welcher bei Betätigung des Ok-Button ausgeführt wird...
            self.uiLabel.text = "Ok-Button wurde betätigt"
        }
        uiAlertController.addAction(OKAction)
        
        self.presentViewController(uiAlertController, animated: true) {
            // Code welcher nach Aufruf des Dialogs ausgeführt wird...
            self.uiLabel.text = "Dialog wird angezeigt!"
        }
    }

    @IBAction func btnActionSheetPressed(sender: AnyObject) {
        let uiActionSheet = UIActionSheet(title: "Beispiel für ein ActionSheet", delegate: self, cancelButtonTitle: "Abbrechen", destructiveButtonTitle: "Löschen", otherButtonTitles: "Ok")
        uiActionSheet.actionSheetStyle = .Default
        uiActionSheet.showInView(self.view)

    }
    
    // MARK: UIActionSheetDelegate
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        switch buttonIndex {
            case 0:
                self.uiLabel.text = "Button Index 0"
            case 1:
                self.uiLabel.text = "Button Index 1"
            case 2:
                self.uiLabel.text = "Button Index 2"
            default:
                self.uiLabel.text = "Default-Zweig"
        
        }
    }
    
    @IBAction func btnAlert3Button(sender: AnyObject) {
        let uiAlertController = UIAlertController(title: "Beispiel", message: "Dialog mit drei Schaltflächen...", preferredStyle: .Alert)
        
        let oneAction = UIAlertAction(title: "Eins", style: .Default) { (action) in
            self.uiLabel.text = "Button 1 wurde betätigt"
        }
        let twoAction = UIAlertAction(title: "Zwei", style: .Default) { (action) in
            self.uiLabel.text = "Button 2 wurde betätigt"
        }
        let threeAction = UIAlertAction(title: "Drei", style: .Default) { (action) in
            self.uiLabel.text = "Button 3 wurde betätigt"
        }
        let cancelAction = UIAlertAction(title: "Abbrechen", style: .Cancel) { (action) in
            self.uiLabel.text = "Abbrechen-Button wurde betätigt"
        }
        
        uiAlertController.addAction(oneAction)
        uiAlertController.addAction(twoAction)
        uiAlertController.addAction(threeAction)
        uiAlertController.addAction(cancelAction)
        
        self.presentViewController(uiAlertController, animated: true) {
            // Code welcher nach Aufruf des Dialogs ausgeführt wird...
            self.uiLabel.text = "Dialog mit Buttons wird angezeigt!"
        }
    }
    
    
    @IBAction func btnDialogWithTextFields(sender: AnyObject) {
       let uiAlertController = UIAlertController(title: "Beispiel", message: "Dialog mit Eingabefeldern...", preferredStyle: .Alert)
        
        let uiAlertLogAction = UIAlertAction(title: "Anmeldung", style: .Default) { (action) in
            let logTextField = uiAlertController.textFields![0] as UITextField
            let pwdTextField = uiAlertController.textFields![1] as UITextField
            
            self.uiLabel.text = "Anmeldung Action!"
           // login(logTextField.text, pwdTextField.text) <- Aufruf einer Methode welche nach Anmeldung ausgeführt wird...
        }
        uiAlertLogAction.enabled = false
        
        let changePwdAction = UIAlertAction(title: "Passwort vergessen", style: .Destructive) { (action) in
            self.uiLabel.text = "Passwort vergssen Action!"
        }
        
        let cancelAction = UIAlertAction(title: "Abbrechen", style: .Cancel) { (action) in
            self.uiLabel.text = "Abbrechen Action!"
        }
        
        uiAlertController.addTextFieldWithConfigurationHandler { (textField) in
            textField.placeholder = "Anmeldung"
            
            NSNotificationCenter.defaultCenter().addObserverForName(UITextFieldTextDidChangeNotification, object: textField, queue: NSOperationQueue.mainQueue()) { (notification) in
                uiAlertLogAction.enabled = textField.text != ""
            }
        }
        
        uiAlertController.addTextFieldWithConfigurationHandler { (textField) in
            textField.placeholder = "Passwort"
            textField.secureTextEntry = true
        }
        
        uiAlertController.addAction(uiAlertLogAction)
        uiAlertController.addAction(changePwdAction)
        uiAlertController.addAction(cancelAction)
        
        self.presentViewController(uiAlertController, animated: true) {
            // Code welcher nach Aufruf des Dialogs ausgeführt wird...
            self.uiLabel.text = "Anmeldedialog wurde angezeigt!"
        }
        
    }
    
    
}

